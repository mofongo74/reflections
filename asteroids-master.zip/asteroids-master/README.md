# HTML5 Asteroids

This game was created Doug McInnes. His code can be found
[here](https://github.com/dmcinnes/HTML5-Asteroids), and you can play his
version of the game online at his website
[here](http://dougmcinnes.com/2010/05/12/html-5-asteroids/).

Caroline Buckey and Sarah Spikes modified the repository to create exercises for
the Udacity course [Version Control Using Git and Github](TODO). These
modifications included introducing bugs and other changes into Doug’s commits he
did not in fact create! The bugs are intended to give learners experience using
Git to find the commit where a bug was introduced. To play the modified version
of the game, simply open the index.html file in your web browser.

Many thanks to Doug for creating this awesome game.
